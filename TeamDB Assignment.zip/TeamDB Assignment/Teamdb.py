#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
"""
Created on Mon Nov 18 13:49:19 2024

@author: anthony
"""
# Store database in storedb variable
storedf = pd.read_csv('storedb.csv')

# Assign Socks column to socks variable 
socks = storedf['Socks']

# Use For loop to display items in Socks Column
for item in list(socks):
    print(item)
    
# Sort Socks Column in Ascending Order
adf = storedf.sort_values(by='Socks', ascending = True)
print(adf)

# Sort Socks Column in Descending Order
ddf = storedf.sort_values(by='Socks', ascending = False)
print(ddf)

# Write the sorted DataFrames to CSV Files
adf.to_csv('teama.csv', index = False)
ddf.to_csv('teamd.csv', index = False)